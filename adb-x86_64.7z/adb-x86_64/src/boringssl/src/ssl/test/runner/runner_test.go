package runner

import "testing"

func TestAll(t *testing.T) {
	main()
}
